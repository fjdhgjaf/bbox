﻿/*
 * PLUGIN SOURCE
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.getSource		= "Obtener .torrent";
 theUILang.cantFindTorrent	= "Archivo torrent original no encontrado.";

thePlugins.get("source").langLoaded();