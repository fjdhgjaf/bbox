﻿/*
 * PLUGIN SOURCE
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.getSource		= "Hämta torrentfil";
 theUILang.cantFindTorrent	= "Torrentfilen för denna nedladdning kunde inte hittas.";

thePlugins.get("source").langLoaded();
