﻿/*
 * PLUGIN THEME
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.themeStandard	= "Tiêu chuẩn";
 theUILang.theme		= "Chủ đề";

thePlugins.get("theme").langLoaded();