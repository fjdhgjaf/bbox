﻿/*
 * PLUGIN THEME
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.themeStandard	= "Стандартна";
 theUILang.theme		= "Палітра";

thePlugins.get("theme").langLoaded();