﻿/*
 * PLUGIN RSSURLREWRITE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.rssNewRule		= "新建规则";
 theUILang.mnu_rssurlrewrite	= "替换 RSS 中 URL 的规则";
 theUILang.rssRulesManager	= "规则管理";
 theUILang.rssAddRule		= "添加";
 theUILang.rssDelRule		= "删除";
 theUILang.rssCheckRule 	= "?";
 theUILang.rssRulesLegend	= "规则设置";
 theUILang.rssSrcHref		= "If URL of torrent download matches pattern";
 theUILang.rssSrcGuid		= "If URL of torrent description matches pattern";
 theUILang.rssDstHref		= "then replace URL of torrent download with";
 theUILang.rssDstGuid		= "then replace URL of torrent description with";
 theUILang.rssRulesDebug	= "规则调试";
 theUILang.rssTestString	= "测试";
 theUILang.rssTestResult	= "结果";
 theUILang.rssURLInfo		= "URL 信息";
 theUILang.rssURLGUID		= "描述 URL";
 theUILang.rssURLHref		= "载入 URL";
 theUILang.rssPatternError	= "模式串中有错误.";
 theUILang.rssStatus		= "RSS";

thePlugins.get("rssurlrewrite").langLoaded();