﻿/*
 * PLUGIN RETRACKERS
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Ajouter des annonces";
 theUILang.retrackersDel	= "Retirer des annonces";
 theUILang.dontAddToPrivate	= "Ne pas toucher aux torrents privés";
 theUILang.addToBegin		= "Ajouter les annonces au début de la liste";

thePlugins.get("retrackers").langLoaded();