﻿/*
 * PLUGIN RETRACKERS
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Dodaj Announces";
 theUILang.retrackersDel	= "Usuń Announces";
 theUILang.dontAddToPrivate	= "Nie modyfikuj prywatnych torrentów";
 theUILang.addToBegin		= "Dodaj announces do początku listy trackerów";
 theUILang.addToBegin		= "Dodaj trackery";

thePlugins.get("retrackers").langLoaded();
