﻿/*
 * PLUGIN XMPP
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 var s_PluginFail			= "Το πρόσθετο δεν θα λειτουργήσει.";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID:";
 theUILang.xmppJabberFor 		= "Παραλήπτης:";
 theUILang.xmppMessage			= "Μήνυμα:";
 theUILang.xmppJabberPasswd		= "Κωδικός:";
 theUILang.xmppAdvancedSettings		= "Προηγμένες:";
 theUILang.xmppJabberHost		= "Διακομιστής:";
 theUILang.xmppJabberPort		= "Θύρα";
 theUILang.xmppUseEncryption		= "Χρήση κρυπτογράφησης";

thePlugins.get("xmpp").langLoaded();
