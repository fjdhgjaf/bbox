﻿/*
 * PLUGIN XMPP
 *
 * French language file.
 *
 * Author: 
 */

 var s_PluginFail			= "Le plug-in ne fonctionnera pas.";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID :";
 theUILang.xmppJabberFor 		= "Destinataire :";
 theUILang.xmppMessage			= "Message :";
 theUILang.xmppJabberPasswd		= "Mot de passe :";
 theUILang.xmppAdvancedSettings		= "Paramètres avancés :";
 theUILang.xmppJabberHost		= "Hôte ";
 theUILang.xmppJabberPort		= "Port ";
 theUILang.xmppUseEncryption		= "Utiliser le chiffrement";

thePlugins.get("xmpp").langLoaded();
