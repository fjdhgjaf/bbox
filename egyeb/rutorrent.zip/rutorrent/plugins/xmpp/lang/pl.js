﻿/*
 * PLUGIN XMPP
 *
 * Polish language file.
 *
 * Author: 
 */

 var s_PluginFail			= "Wtyczka nie będzie działać";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID:";
 theUILang.xmppJabberFor 		= "Recipient:";
 theUILang.xmppJabberFor 		= "Odbiora:";
 theUILang.xmppMessage			= "Wiadomość:";
 theUILang.xmppJabberPasswd		= "Hasło:";
 theUILang.xmppAdvancedSettings		= "Zaawansowane:";
 theUILang.xmppJabberHost		= "Host:";
 theUILang.xmppJabberPort		= "Port";
 theUILang.xmppUseEncryption		= "Używaj szyfrowania";

thePlugins.get("xmpp").langLoaded();
