﻿/*
 * PLUGIN UNPACK
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.unpack		= "Descomprimir";
 theUILang.unpackPath		= "Descomprimir a (deje en blanco para la carpeta actual):";
 theUILang.unzipNotFound	= "No se puede localizar unzip.";
 theUILang.unrarNotFound	= "No se puede localizar unrar.";
 theUILang.unpackEnabled	= "Descomprimir automaticamente";
 theUILang.unpackTorrents	= "Agregar a la ruta cuando se descomprima:";
 theUILang.unpackAddLabel	= "Etiqueta del Torrent";
 theUILang.unpackAddName	= "Nombre del Torrent";

thePlugins.get("unpack").langLoaded();