﻿/*
 * PLUGIN SeedingTime
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se)
 */

 theUILang.seedingTime		= "Färdig";
 theUILang.addTime		= "Tillagd";

thePlugins.get("seedingtime").langLoaded();