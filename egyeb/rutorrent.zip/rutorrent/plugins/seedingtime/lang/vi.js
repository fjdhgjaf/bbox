﻿/*
 * PLUGIN SeedingTime
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.seedingTime		= "Đã hoàn thành";
 theUILang.addTime		= "Đã thêm vào";

thePlugins.get("seedingtime").langLoaded();