﻿/*
 * PLUGIN TRAFFIC
 *
 * German language file.
 *
 * Author: 
 */

 theUILang.traf 	= "Traffic";
 theUILang.perDay	= "Pro Tag";
 theUILang.perMonth 	= "Pro Monat";
 theUILang.perYear 	= "Pro Jahr";
 theUILang.allTrackers	= "Alle Tracker";
 theUILang.ClearButton	= "Löschen";
 theUILang.ClearQuest 	= "Willst du die Statistik des ausgewählten Trackers wirklich löschen?";
 theUILang.selectedTorrent	= "Ausgewählter Torrent(s)";
 theUILang.ratioDay	= "Ratio/tag";
 theUILang.ratioWeek	= "Ratio/woche";
 theUILang.ratioMonth	= "Ratio/monat";
