﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.exFFMPEG		= "스크린샷";
 theUILang.exFrameWidth 	= "프레임 너비";
 theUILang.exFramesCount	= "프레임 개수";
 theUILang.exStartOffset	= "시작 프레임 위치";
 theUILang.exBetween		= "프레임 간 시간 간격";
 theUILang.exSave		= "저장";
 theUILang.exSaveAll		= "모두 저장";
 theUILang.exScreenshot 	= "스크린샷";
 theUILang.exPlayInterval	= "슬라이드 쇼 간격";
 theUILang.exImageFormat	= "이미지 형식";

thePlugins.get("screenshots").langLoaded();
