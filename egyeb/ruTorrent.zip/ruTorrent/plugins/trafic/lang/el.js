﻿/*
 * PLUGIN TRAFFIC
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.traf 		= "Κίνηση";
 theUILang.perDay		= "Ανά ημέρα";
 theUILang.perMonth		= "Ανά μήνα";
 theUILang.perYear		= "Ανά χρόνο";
 theUILang.allTrackers		= "Όλοι οι trackers";
 theUILang.ClearButton		= "Εκκαθάριση";
 theUILang.ClearQuest		= "Θέλετε πραγματικά να κάνετε εκκαθάριση των στατιστικών για τους επιλεγμένους tracker;";
 theUILang.selectedTorrent	= "Επιλεγμένο/α torrent(s)";
 theUILang.ratioDay		= "Αναλογία/ημέρα";
 theUILang.ratioWeek		= "Αναλογία/εβδομάδα";
 theUILang.ratioMonth		= "Αναλογία/μήνα";
