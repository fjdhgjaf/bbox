﻿/*
 * PLUGIN THROTTLE
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.throttles		= "Beperkingen";
 theUILang.throttle		= "Snelheidsbeperking";
 theUILang.mnuThrottle		= "Zet beperking";
 theUILang.mnuUnlimited 	= "Geen Beperking";
 theUILang.channelName		= "Naam";
 theUILang.channelDefault	= "Default channel";

thePlugins.get("throttle").langLoaded();