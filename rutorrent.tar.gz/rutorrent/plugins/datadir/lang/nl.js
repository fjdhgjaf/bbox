﻿/*
 * PLUGIN DATADIR
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.DataDir		= "Opslaan in";
 theUILang.DataDirMove		= "Verplaats bestanden";
 theUILang.datadirDlgCaption	= "Torrent data map";
 theUILang.datadirDirNotFound	= "DataDir plugin: Ongeldige map";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operatie mislukt";
 theUILang.datadirPHPNotFound	= "DataDir plugin: rTorrent gebruiker heeft geen toegang tot de PHP-interpreter. De plugin zal niet werken.";

thePlugins.get("datadir").langLoaded();