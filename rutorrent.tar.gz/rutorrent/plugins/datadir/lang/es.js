﻿/*
 * PLUGIN DATADIR
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Guardar en";
 theUILang.DataDirMove		= "Mover datos";
 theUILang.datadirDlgCaption	= "Directorio de datos del Torrent";
 theUILang.datadirDirNotFound	= "DataDir plugin: Directorio inválido";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operación fallida";
 theUILang.datadirPHPNotFound	= "DataDir plugin: rTorrent no puede acceder al intérprete PHP. El Plugin no funcionará.";

thePlugins.get("datadir").langLoaded();