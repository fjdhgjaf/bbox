plugin.loadCSS('jquery.noty');
plugin.loadCSS('noty_theme_default');
injectScript(plugin.path+"jquery.noty.js");
