﻿/*
 * PLUGIN CREATE
 *
 * Hungarian language file.
 *
 * Author: Tiby08
 */

 theUILang.mnu_create			= "Torrent létrehozása...";
 theUILang.CreateNewTorrent		= "Új torrent létrehozása";
 theUILang.SelectSource 		= "Forrás kiválasztása";
 theUILang.TorrentProperties		= "Torrent tulajdonságok";
 theUILang.PieceSize			= "Szeletméret";
 theUILang.Other			= "Egyéb";
 theUILang.StartSeeding 		= "Seedelés indítása";
 theUILang.PrivateTorrent		= "Magán torrent";
 theUILang.torrentCreate		= "Létrehozás...";
 theUILang.BadTorrentData		= "Az összes szükséges mezőt ki kell tölteni!";
 theUILang.createExternalNotFound	= "Torrent létrehozás bővitmény: Bővitmény nem fog működni! Webserver felhasználó nem fér hozzá a programhoz";
 theUILang.incorrectDirectory		= "Helytelen könyvtár";
 theUILang.cantExecExternal		= "Nem lehet végrehajtani a külső programmal";
 theUILang.createConsole		= "Konsole";
 theUILang.createErrors 		= "Hiba";
 theUILang.torrentSave			= "Mentés";
 theUILang.torrentKill			= "Megállít";
 theUILang.torrentKilled		= "Folyamat leállt.";

thePlugins.get("create").langLoaded();