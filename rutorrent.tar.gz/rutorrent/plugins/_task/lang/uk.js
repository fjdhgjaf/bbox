﻿/*
 * PLUGIN _TASK
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.tskCommand		= "Триває виконання команди...";
 theUILang.tskCommandDone	= "Виконання команди завершено.";
 theUILang.tskConsole		= "Консоль";
 theUILang.tskErrors		= "Діагностика";

thePlugins.get("_task").langLoaded();