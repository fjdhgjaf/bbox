﻿/*
 * PLUGIN DISKSPACE
 *
 * Hungarian language file.
 *
 * Author: Tiby08
 */

 theUILang.diskNotification = "Figyelmeztetés! A lemez megtelt. rTorrent nem működik rendesen, és nem tud több adatot letölteni, míg nem szabadít fel helyet.";

thePlugins.get("diskspace").langLoaded();