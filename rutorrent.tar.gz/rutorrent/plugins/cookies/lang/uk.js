﻿/*
 * PLUGIN COOKIES
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.cookiesDesc = "Файли cookie (Формат: вузол|cookie1;cookie2...)";
 theUILang.cookiesName = "Файли cookie";

thePlugins.get("cookies").langLoaded();